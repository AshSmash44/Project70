import React from 'react';
import {View,TouchableOpacity,TextInput,StyleSheet,KeyboardAvoidingView,Text,} from 'react-native';


export default class WriteStoryScreen extends React.Component {
  render(){
    return(
      <View>
        <Text>Reading stories (totally)</Text>
      </View>
    )
  }
}

