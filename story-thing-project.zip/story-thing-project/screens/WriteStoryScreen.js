import React from 'react';
import {View,TouchableOpacity,TextInput,StyleSheet,KeyboardAvoidingView,Text} from 'react-native';

export default class WriteStoryScreen extends React.Component {
  render(){
    return(
      <View>
        <TextInput
          style={styles.textBox1}
          placeholder='Name of book'
        />
        <TextInput
          style={styles.textBox2}
          placeholder='Name of Author'
        />
        <TextInput
          style={styles.textBox3}
          placeholder='Story'
        />
          <TouchableOpacity
          style={{
            height:30,
            width:90,
            borderWidth:3,
            marginTop:30,
            borderRadius:7,
            alignSelf:'center',
            backgroundColor:'#FFA500',
          }}
          >
          <Text style={styles.buttonText}>Post  story</Text>
          </TouchableOpacity>
      </View>
    )
  }
}

const styles = StyleSheet.create({
  textBox1:{
  width: 300,
  height: 50,
  borderWidth: 1.5,
  fontSize: 20,
  margin: 10,
  marginTop : 70,
  paddingLeft: 10,
  borderRadius: 3,
  alignSelf:'center',
  },
  textBox2:{
  width: 300,
  height: 50,
  borderWidth: 1.5,
  fontSize: 20,
  margin: 10,
  marginTop : 20,
  paddingLeft: 10,
  borderRadius: 3,
  alignSelf:'center',
  },
  textBox3:{
  width: 300,
  height: 250,
  borderWidth: 1.5,
  fontSize: 20,
  margin: 10,
  marginTop : 20,
  paddingLeft: 10,
  borderRadius: 3,
  alignSelf:'center',
  },
  buttonText:{
    fontSize:16,
    alignSelf:'center',
  }
})